# REST + MCP specification

## REST

### `POST /v1/arena/runs`
Create a recommendation run.

Request:
```json
{
  "description": "API that verifies factual claims against primary sources",
  "audiences": ["developer", "ai_agent"],
  "constraints": {
    "max_purchase_price": 20,
    "max_renewal_price": 30,
    "premium_allowed": false,
    "allowed_tlds": ["com", "dev", "io"]
  },
  "mode": "quick"
}
```

### `GET /v1/arena/runs/{run_id}`
Progress + candidate funnel.

### `GET /v1/arena/runs/{run_id}/results`
Pareto set, per-signal metrics, recommendation and evidence.

### `POST /v1/decisions/{decision_id}/refresh`
Refresh final name.com availability/pricing.

### `POST /v1/decisions/{decision_id}/approve`
Explicit approval with max total price.

### `POST /v1/decisions/{decision_id}/register`
Register only if approved and fresh checks pass.

### `POST /v1/registrations/{id}/dns-receipt`
Create/fetch-back DomainArena TXT receipt.

## MCP tools

### `recommend_domain`
Read-only. Inputs mirror `DomainIntent + ConstraintSet`.

### `compare_domains`
Read-only. Compare a supplied domain set using existing evidence or a bounded evaluation.

### `explain_domain`
Read-only. Return why a candidate is/was recommended and all uncertainty.

### `refresh_domain_offer`
Read-only. Recheck price/availability.

### `register_domain`
Destructive. Requires explicit approval object or pre-authorized policy ID.

### `configure_domain_receipt`
Destructive DNS write, gated to a domain controlled by the connected account.

## Agent-native response philosophy

Return structured evidence, not prose-only judgments.

```json
{
  "recommended_domain": "factprobe.dev",
  "inventory": {
    "purchasable": true,
    "purchase_price": 14.99,
    "renewal_price": 14.99,
    "premium": false,
    "checked_at": "..."
  },
  "evidence": {
    "semantic_transmission": {"value": 0.86, "coverage": "6/8"},
    "pairwise": {"strength": 1.21, "rank_spread": [1, 2]},
    "model_stability": {"worst_family": 0.76, "dispersion": 0.05}
  },
  "constraint_proof": {
    "purchase_under_budget": true,
    "renewal_under_ceiling": true,
    "premium_policy_satisfied": true
  },
  "decision_id": "da_dec_...",
  "purchase_requires_approval": true
}
```
