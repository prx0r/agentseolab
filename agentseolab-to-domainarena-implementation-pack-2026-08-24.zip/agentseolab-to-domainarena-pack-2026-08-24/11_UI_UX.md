# UI / UX

## Inspiration

Use Arena's clarity around comparison, uncertainty and live ranking, but make the interface about **evidence channels**, not a single popularity leaderboard.

## Screen 1 — Intent + policy

Primary prompt box:
> What are you building?

Then:
- Who must understand the name? `Consumers / Businesses / Developers / AI Agents`
- First-year budget
- Renewal ceiling
- premium on/off
- TLD allowlist
- Precision ↔ Elasticity preference
- Quick / Deep Arena

Important: default to a sensible audience preset instead of asking users to tune ten weights.

## Screen 2 — Live inventory funnel

Show:

```text
Generated                     180
name.com purchasable           91
Within first-year budget       54
Within renewal ceiling         46
Deterministic screen           30
Semantic Arena                 12
Executable/pairwise finalists   6
Pareto finalists                3
```

The name.com role should be visibly central.

## Screen 3 — Arena

For the human user, allow optional blinded pairwise battles:

```text
Which better fits this product?
[ candidate A ]   [ candidate B ]
```

But do not make human votes the only ranking source.

Parallel panel:
- AI evaluator families running
- semantic inversion results
- actual task selection trials

## Screen 4 — Result matrix

Rows = candidates. Columns = evidence channels.

```text
                 Semantics  Agent select  Stability  Human memory  Price
factprobe.dev       .86        .78          .93          —         $14
truthfox.io         .91        .82          .54          —         $18
factmole.dev        .82        .76          .95          —         $12
```

Highlight:
- highest mean
- highest worst-family
- recommended under current policy

Do not hide disagreement.

## Screen 5 — Candidate detail

Show:
- what different model families inferred from hostname alone
- generator/lineage
- name.com inventory snapshot
- constraint proof
- pairwise battle history
- TLD evidence
- uncertainty/rank spread
- known limitations

## Screen 6 — Registration

```text
factprobe.dev
$14.99 first year
$14.99 renewal
Premium: no
Fresh availability: 7 seconds ago

[Approve sandbox registration]
```

After success:

```text
REGISTERED ✓
LOCK/PRIVACY STATUS ...
DNS RECEIPT ✓
DECISION RECEIPT da_dec_...
```

## Visual signature

The best distinctive visual is an **evolution/lineage tree** where candidates are killed by:
- unavailable
- over budget
- renewal too high
- poor semantic transmission
- unstable across model families

and winners mutate into the next generation.
