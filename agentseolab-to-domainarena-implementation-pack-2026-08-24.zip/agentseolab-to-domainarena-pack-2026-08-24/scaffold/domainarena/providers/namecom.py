"""name.com Core API scaffold.

Intentionally excludes credentials and the final CreateDomain payload because account/contact
requirements must be wired against the current official schema. Use sandbox first.
"""
from __future__ import annotations
import base64
import httpx

class NameComError(RuntimeError):
    pass

class NameComClient:
    def __init__(self, username: str, token: str, base_url: str = "https://api.dev.name.com", timeout: float = 15.0):
        raw = f"{username}:{token}".encode()
        auth = base64.b64encode(raw).decode()
        self.client = httpx.AsyncClient(
            base_url=base_url,
            timeout=timeout,
            headers={"Authorization": f"Basic {auth}", "Content-Type": "application/json"},
        )

    async def _request(self, method: str, path: str, **kwargs):
        r = await self.client.request(method, path, **kwargs)
        if r.status_code >= 400:
            raise NameComError(f"name.com {r.status_code}: {r.text[:1000]}")
        return r.json()

    async def search(self, keyword: str, tlds: list[str], timeout_ms: int = 2500):
        return await self._request("POST", "/core/v1/domains:search", json={
            "keyword": keyword,
            "timeout": timeout_ms,
            "tldFilter": [t.lower().lstrip('.') for t in tlds][:50],
            "purchaseType": "registration",
        })

    async def check_availability(self, domains: list[str]):
        if not 1 <= len(domains) <= 50:
            raise ValueError("name.com CheckAvailability supports 1..50 domains per call")
        return await self._request("POST", "/core/v1/domains:checkAvailability", json={"domainNames": domains})

    async def get_pricing(self, domain: str):
        return await self._request("GET", f"/core/v1/domains/{domain}:getPricing")

    async def get_domain(self, domain: str):
        return await self._request("GET", f"/core/v1/domains/{domain}")

    async def update_domain(self, domain: str, *, autorenew: bool | None = None, privacy: bool | None = None, locked: bool | None = None):
        body = {}
        if autorenew is not None: body["autorenewEnabled"] = autorenew
        if privacy is not None: body["privacyEnabled"] = privacy
        if locked is not None: body["locked"] = locked
        return await self._request("PATCH", f"/core/v1/domains/{domain}", json=body)

    async def create_dns_record(self, domain: str, *, host: str, record_type: str, answer: str, ttl: int = 300):
        return await self._request("POST", f"/core/v1/domains/{domain}/records", json={
            "host": host,
            "type": record_type,
            "answer": answer,
            "ttl": max(300, ttl),
        })

    async def register_domain(self, payload: dict, idempotency_key: str):
        # Wire `payload` to the current official Create Domain schema + account contact policy.
        # Never call this without a fresh availability/pricing check and explicit approval state.
        headers = {"X-Idempotency-Key": idempotency_key}
        return await self._request("POST", "/core/v1/domains", json=payload, headers=headers)
