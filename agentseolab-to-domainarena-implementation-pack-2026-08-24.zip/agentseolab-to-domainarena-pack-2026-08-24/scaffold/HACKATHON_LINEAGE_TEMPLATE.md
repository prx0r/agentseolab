# Hackathon lineage

## Baseline
- Date/time:
- Commit SHA:
- Tag:
- Existing capabilities:

## DomainArena-specific work
| Commit | Date | Capability | New vs adapted | Source if adapted |
|---|---|---|---|---|

## Related source ports
| Source repo/path/SHA | Destination | Changes |
|---|---|---|

## Claims discipline
- Pre-existing experimental findings are labeled with their original dates.
- Planned experiments are not reported as measured findings.
- Invalidated/failed replications remain visible.
