# AgentSEOLab → DomainArena implementation pack

**Date:** 2026-08-24  
**Canonical repository:** `prx0r/agentseolab`  
**Target product:** **DomainArena — evidence-based domain selection for humans and agents**

This pack is a migration/build specification for evolving the existing AgentSEOLab repository into the DevNetwork API + Cloud + AI Hackathon name.com entry without discarding or disguising the existing research lineage.

## Core product thesis

> **Stop asking an AI which domain sounds good. Test which domain actually works.**

DomainArena treats domain choice as a constrained empirical optimization problem. A user or agent supplies a product intent and hard constraints such as purchase budget, renewal ceiling, TLD set and target audience. DomainArena generates candidate names, intersects them with live name.com inventory, and then evaluates the feasible candidates on separate outcome channels:

1. **semantic transmission** — can an evaluator infer the intended job from the hostname alone?
2. **agent selection** — when exposed to equivalent alternatives, which hostname causes an agent to select the right capability?
3. **invocation/task success** — does that selection lead to a successful tool/API invocation?
4. **model stability** — does the effect survive across model families and serving windows?
5. **human memory/trust** — when humans are actually part of the target market, can they remember, spell and trust the name?
6. **brand elasticity** — does the name communicate enough now without trapping the product in one category?
7. **economics** — is the domain purchasable now under the user's acquisition and renewal budget?

The winning candidate can then be rechecked, registered and configured through the name.com API.

## The most important design decision

**Human liking is not the universal objective.** It is one signal whose importance depends on who chooses, invokes and pays for the product.

For a machine-facing MCP/API, a human saying “this sounds cool” may have close to zero direct value. Agent task inference, retrieval/selection, invocation success, stability and cost matter more. For a consumer brand, human memorability, pronunciation, trust and word-of-mouth still matter heavily. DomainArena therefore does **audience-conditioned evaluation**, not one universal `domain_score`.

## Build order

Read in this order:

1. `00_EXECUTIVE_DECISION.md`
2. `01_RESEARCH_CONCLUSIONS.md`
3. `02_PRODUCT_SPEC.md`
4. `03_REPO_TRANSITION.md`
5. `04_ARCHITECTURE.md`
6. `05_NAMECOM_INTEGRATION.md`
7. `06_NAMING_ENGINE.md`
8. `07_EXPERIMENTAL_PROTOCOL.md`
9. `08_AGENTIC_SEO.md`
10. `09_DATA_MODEL.md`
11. `10_API_MCP_SPEC.md`
12. `11_UI_UX.md`
13. `12_BUILD_ORDER.md`
14. `13_TICKET_BACKLOG.md`
15. `14_TEST_PLAN.md`
16. `15_HACKATHON_SUBMISSION.md`
17. `16_DEMO_SCRIPT.md`
18. `17_LINEAGE_AND_COMPLIANCE.md`
19. `18_SOURCE_MAP.md`

`scaffold/` contains implementation-oriented schemas and skeleton modules. It is intentionally a scaffold, not a claim that the product code is already complete.
