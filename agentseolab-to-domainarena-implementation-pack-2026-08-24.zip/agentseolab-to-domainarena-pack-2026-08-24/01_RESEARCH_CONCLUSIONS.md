# Research conclusions that should drive features

## 1. Human preference is no longer the default ground truth

Traditional “best domain” products implicitly optimize for a human founder's aesthetic reaction. That is insufficient in an agent-mediated web.

Arena's own evolution is instructive: its classic leaderboards use pairwise preferences, while its 2026 Agent Arena evaluates real-world traces using confirmed success, steerability, tool errors and other behavioral signals. The lesson is that **preference is not the same as utility**.

DomainArena should mirror that shift:

```text
LIKING < MEMORY/TRUST < CORRECT INTERPRETATION < SELECTION < INVOCATION < TASK SUCCESS < REUSE
```

Not every product needs every layer, and the weights depend on the audience.

## 2. Human signals still matter — but only where humans remain in the causal path

Human preference is not irrelevant. It becomes **conditional**.

### Machine-facing API / MCP tool
Priority should be approximately:
- agent intent inference
- agent selection under controlled exposure
- successful invocation
- model-family stability
- query-language alignment
- price/renewal economics
- human preference: low weight

### Developer tool
Priority should be mixed:
- agent discoverability + invocation
- developer comprehension
- pronounceability / memory
- trust
- stability
- economics

### Consumer brand
Human signals remain central:
- memory
- pronunciation/spelling reconstruction
- trust/credibility
- emotional/brand fit
- semantic transmission
- search/agent interpretation as a secondary distribution channel

Thus the UI should ask **who must understand this name?** before it asks what style the user likes.

## 3. Model disagreement is a product feature, not noise to average away

AgentSEOLab already observed family-specific selection behavior and serving-window nondeterminism. A domain chosen for years should not be optimized against one transient model.

DomainArena should surface:
- per-family semantic transmission
- per-family selection rate
- worst-family outcome
- dispersion / stability
- rerun drift over time

A candidate with slightly lower mean but high floor can be preferable to a spiky candidate that one model loves and another completely misunderstands.

## 4. Retrieval and selection must be separated

Agentic SEO is not “put the right keyword in the domain and the LLM will rank it.” Current AI-search research finds large engine differences, authority/source effects and sensitivity to phrasing. Search-agent security work also shows agents can be influenced by surface and evidence-chain signals.

DomainArena should therefore maintain separate estimands:

```text
P(exposed | query, engine)
P(selected | exposed, hostname, snippet, task)
P(invoked | selected, tool metadata)
P(success | invoked)
P(reuse | prior success)
```

A hostname experiment only supports claims about the stage it manipulates.

## 5. Agent query language is functional

AgentSEOLab QLEX found first-query convergence around functional noun/verb phrases rather than branding language. This makes **functional semantic transmission** valuable for agent-facing products.

Feature consequence:
- derive a query lexicon from the intent before generating names;
- measure overlap and, more importantly, whether agents infer the correct task from the hostname;
- do not mechanically keyword-stuff names.

## 6. TLD should be an experimentally learned interaction

AgentSEOLab already has a controlled TLD experiment. Do not encode `.com + 10`, `.dev + 8` globally.

Model:

```text
TLD effect = f(task_type, audience, model_family, context)
```

If evidence is insufficient, label the effect **unknown** rather than filling it with intuition.

## 7. Real inventory and economics must constrain generation

name.com's Search API returns real purchasability, premium status, purchase price, renewal price and purchase type. Therefore “under $20” is not a soft preference.

First define the feasible set:

```text
F = purchasable
  ∩ purchase_price <= budget
  ∩ renewal_price <= ceiling
  ∩ allowed TLDs
  ∩ premium policy
  ∩ purchase type policy
```

Only then spend inference on quality.

## 8. Aesthetics should be decomposed into measurable human outcomes

“Do you like this?” is a weak signal. Better human tests include:
- free recall after a distractor
- recognition among lures
- spelling reconstruction
- speech-to-domain transcription
- trust/credibility under controlled presentation
- category inference

These are useful especially for consumer/developer products.

## 9. Domain names may become machine-readable identity anchors

Recent research argues DNS is a plausible substrate for agent discovery because it is ubiquitous, low-latency and capable of carrying discovery/trust metadata. This supports a future DomainArena extension where registration can publish machine-readable records, but **that is secondary to the naming engine for this hackathon**.

## 10. The valuable long-run dataset is revealed behavior

The durable asset is not generated names. It is the event stream:

```text
intent
→ candidate inventory
→ controlled evaluations
→ recommendation
→ registration decision
→ exposure
→ selection
→ invocation
→ task success
→ reuse
```

That can eventually train/calibrate recommendation policies with real outcomes.
