# Agentic SEO: what DomainArena should actually mean

## Do not turn AgentSEOLab into keyword astrology

Agentic SEO should mean **measurement of the machine discovery funnel**, not claims that domain keywords magically cause AI rankings.

## Canonical funnel

```text
QUERY / TASK
   ↓
EXPOSED in search/tool discovery
   ↓
OPENED / SOURCE READ
   ↓
CAPABILITY SELECTED
   ↓
INVOKED
   ↓
EXECUTION SUCCEEDED
   ↓
TASK VERIFIED
   ↓
REUSED
```

Each is a separate event and estimand.

## Features that follow from this

### Query Lexicon panel
Derive the functional language agents actually use for the intent. QLEX suggests agents often converge on functional noun/verb phrases. Show this as evidence, not a name-stuffing instruction.

### Semantic Transmission
Can the hostname communicate the task when no description is supplied?

### Discovery Counterfactual
Where feasible, keep result title/snippet/content constant and vary hostname/TLD.

### Tool Selection Counterfactual
Expose otherwise-equivalent tools with hostname/identity changes and measure actual tool call.

### Verification/Trust channel
AgentSEOLab VERIF experiments can later test whether truthful provenance/verification signals alter selection. Keep this separate from the hostname effect.

### Field Mode
Once DomainArena has its own deployed examples, collect exposure → invocation → reuse telemetry.

## Why a human-friendly name can still matter in agentic SEO

Even when an agent discovers the site, humans may:
- approve the recommendation
- click a cited source
- verbally share the brand
- remember it later
- decide whether to trust/pay

Therefore the correct question is not “humans or agents?” It is:

> **Which actors participate in this product's actual adoption path?**

DomainArena's audience preset encodes that answer.

## Research-safe claims for the hackathon

Good:
- “We measure whether different model families infer the intended task from a domain.”
- “We measure hostname/TLD effects under controlled exposure.”
- “We keep selection distinct from task success.”
- “Budget and live inventory constrain the optimization.”

Bad:
- “This domain will rank #1 in ChatGPT.”
- “.dev is universally better for agents.”
- “Agents don't care about human branding.”
- “Our 94 score predicts revenue.”
