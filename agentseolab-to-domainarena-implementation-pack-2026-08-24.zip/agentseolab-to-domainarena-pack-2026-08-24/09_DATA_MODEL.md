# Data model

## Minimum tables / collections

### `domain_intents`
- `intent_id`
- `intent_hash`
- canonical JSON payload
- created_at

### `arena_runs`
- `run_id`
- `intent_id`
- policy preset
- constraints JSON
- status
- created_at/completed_at

### `candidates`
- `candidate_id`
- `run_id`
- `domain_name`
- `sld`, `tld`
- generator family
- generation
- parents JSON
- mutation

### `inventory_snapshots`
- candidate/domain
- provider=`name.com`
- purchasable
- premium
- purchase_price
- renewal_price
- purchase_type
- reason
- checked_at
- raw hash

### `experiment_manifests`
- `manifest_id`
- experiment type
- intent hash
- candidate set hash
- prompt/template hash
- evaluator panel
- preregistered metric
- created_at

### `trials`
- trial_id
- manifest_id
- candidate(s)
- ordering
- model family/provider/model ID
- session ID
- raw output
- parsed outcome
- unparseable flag
- latency/cost if known
- timestamp

### `candidate_metrics`
Derived and rebuildable:
- semantic transmission
- pairwise strength
- Wilson/BT uncertainty
- model stability
- worst-family outcome
- task recognition
- TLD effect evidence link
- human metrics

### `decisions`
- decision_id
- run_id
- recommended candidate
- Pareto set
- policy version
- rationale JSON
- evidence hash
- created_at

### `approvals`
- decision_id
- approval mode
- actor
- approved price cap
- timestamp

### `registrations`
- decision_id
- domain
- name.com idempotency key
- pre-purchase availability snapshot
- response/order identifiers
- total paid/test paid
- mode sandbox/production
- timestamp

### `dns_receipts`
- registration
- record ID
- host/type/value
- created_at
- verified/fetched_back

## Event ontology

Prefer append-only event records in addition to tables:

```text
INTENT_FROZEN
CANDIDATE_GENERATED
INVENTORY_CHECKED
CANDIDATE_FILTERED
TRIAL_STARTED
TRIAL_COMPLETED
TRIAL_UNPARSEABLE
METRIC_DERIVED
DECISION_CREATED
DECISION_APPROVED
AVAILABILITY_RECHECKED
REGISTRATION_REQUESTED
REGISTRATION_SUCCEEDED
DNS_RECEIPT_CREATED
```

This keeps the eventual Hydra/evidence-graph bridge easy.
