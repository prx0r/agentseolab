# 2–4 minute demo script

## 0:00–0:20 — problem

Show a generic model producing confident domain suggestions.

Narration:
> AI naming tools generate names and then ask AI to grade its own homework. Worse, many suggestions are unavailable, too expensive, or interpreted differently by different models.

## 0:20–0:40 — intent

Enter:

> “Evidence-verification API for developers and AI agents. First year <= $20, renewal <= $30, no premium, .com/.dev/.io.”

Emphasize that audience and economics are part of the task.

## 0:40–1:05 — name.com inventory

Show funnel live:
- generated candidates
- name.com Search results
- unavailable removed
- over-budget removed
- high-renewal removed

Narration:
> We don't rank imaginary names. name.com defines the purchasable search space.

## 1:05–1:35 — semantic inversion

Show 2–3 hostname-only interpretations by different model families.

Narration:
> Instead of asking if a name “sounds good,” we hide the product description and measure whether independent models infer the right job from the hostname alone.

## 1:35–2:00 — disagreement/stability

Show matrix where a flashy candidate wins one model but fails others; robust candidate has a higher floor.

Narration:
> Domains last years. We don't optimize a permanent identity for one temporary model.

## 2:00–2:20 — agentic SEO / executable selection

Show controlled task where an agent must choose/invoke an equivalent tool identity and task success is verified.

Narration:
> Preference isn't the endpoint. AgentSEOLab measures what agents actually select and whether the task succeeds.

## 2:20–2:40 — recommendation

Show Pareto finalists and constraint proof.

> `factprobe.dev` recommended: $X purchase, $Y renewal, stable across N model families, semantic transmission Z, all constraints satisfied.

Do not invent numeric results; use actual run output.

## 2:40–3:10 — name.com action

Click approve.

System:
- refresh CheckAvailability
- show current price
- sandbox CreateDomain
- create `_domainarena` TXT receipt
- fetch record back

## 3:10–3:30 — close

> name.com solved the rails for agents to buy and manage domains. DomainArena adds the missing decision layer: which domain should an agent buy, for this task, under these constraints, and what evidence supports that choice?
