# name.com integration

## Why name.com is structurally central

DomainArena does not generate hypothetical names and add a checkout link at the end. Live name.com inventory **defines the feasible optimization space**.

The sponsor challenge explicitly rewards integration depth and gives search + registration + DNS as the example of a strong multi-endpoint integration.

## Required endpoints

### Search
`POST /core/v1/domains:search`

Use for keyword/TLD discovery. Relevant response fields include:
- `domainName`
- `purchasable`
- `sld`
- `tld`
- `premium`
- `purchasePrice`
- `renewalPrice`
- `purchaseType`
- `reason`

Use `purchaseType=registration` by default for predictable, immediately fulfillable inventory unless the user explicitly enables aftermarket categories.

### Check availability
`POST /core/v1/domains:checkAvailability`

Use for batch verification and **always immediately before purchase**. Maximum documented list size: 50 domains per call.

### Domain pricing
`GET /core/v1/domains/{domainName}:getPricing`

Use when a specific finalist needs refreshed registration/renewal pricing.

### Create/register domain
Use the Core API Create Domain endpoint with a unique `X-Idempotency-Key`.

Never perform a registration from a stale recommendation without a new availability/pricing check.

### Domain update
`PATCH /core/v1/domains/{domainName}`

Use for lock/privacy/autorenew settings if part of the demo/account policy.

### DNS record
`POST /core/v1/domains/{domainName}/records`

Use DNS meaningfully: write a DomainArena receipt or agent-discovery metadata after registration.

Example:

```text
_host: _domainarena
_type: TXT
_value: decision=da_...;intent=sha256:...;manifest=...
```

Then list/fetch the record and show it in the final receipt.

## Sandbox

Build and demo against the name.com sandbox first. Keep production credentials disabled by default.

Config:

```env
NAMECOM_BASE_URL=https://api.dev.name.com
NAMECOM_USERNAME=...
NAMECOM_TOKEN=...
NAMECOM_MODE=sandbox
```

Never commit credentials.

## Constraint policy

```python
feasible = (
    result.purchasable
    and result.purchase_type == 'registration'
    and result.purchase_price <= max_purchase
    and result.renewal_price <= max_renewal
    and (premium_allowed or not result.premium)
    and result.tld in allowed_tlds
)
```

Budget is a hard filter, not a scoring bonus.

## Registration safety

Recommendation and purchase must be separate operations.

```text
recommend_domain()     read-only
approve_decision()     explicit state transition
register_domain()      destructive, gated
```

Agent mode may support a pre-authorized policy later, but the hackathon demo should visibly show the approval boundary.

## Useful sponsor-level metrics to log

- searches per recommendation
- candidates returned by name.com
- candidates filtered by price
- candidates filtered by renewal
- candidates filtered by premium policy
- recommendation → approval rate
- approval → successful registration rate
- chosen TLD distribution by intent/audience
- price elasticity by intent category

These are the beginnings of a conversion-intelligence dataset that could matter to name.com.
