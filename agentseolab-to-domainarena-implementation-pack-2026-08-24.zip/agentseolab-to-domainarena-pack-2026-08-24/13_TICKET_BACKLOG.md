# Implementation ticket backlog

## Epic A — lineage/product framing

### DA-001 Baseline tag + lineage document
**Acceptance:** current pre-product SHA recorded; tag pushed; no history rewrite.

### DA-002 README product framing
**Acceptance:** DomainArena visible above fold; AgentSEOLab described as research engine; no unsupported claims.

## Epic B — name.com

### DA-010 NameCom client
Methods: search, check availability, get pricing, register, get/update domain, create/list DNS.

### DA-011 Sandbox contract tests
Use mocked contract tests plus opt-in live sandbox tests.

### DA-012 Constraint engine
Hard purchase/renewal/premium/TLD filters.

### DA-013 Purchase state machine
`RECOMMENDED → REFRESHED → APPROVED → REGISTERING → REGISTERED/FAILED`.

### DA-014 Idempotency
Stable key per approved decision/attempt semantics; test retry path.

### DA-015 DNS receipt
Create and fetch back a TXT record tied to decision/manifest.

## Epic C — intent/generation

### DA-020 DomainIntent compiler
Freeze canonical JSON + SHA256.

### DA-021 Generator registry
Every candidate stores generator and lineage.

### DA-022 Port deterministic domain normalization/features
Source-map from domainnamechecker.

### DA-023 name.com population source
Use Search keyword/TLD suggestions as part of generation.

## Epic D — Arena

### DA-030 Semantic inversion manifest
Hostname-only evaluator task with distractor generation.

### DA-031 Semantic inversion runner
Multi-family, fresh sessions, raw events.

### DA-032 Pairwise AB/BA runner
Counterbalanced candidate order.

### DA-033 Bradley–Terry estimator
Test on synthetic known-strength fixture.

### DA-034 Executable selection environment
Manipulate hostname while holding tool capability constant; verify actual task outcome.

### DA-035 Stability report
Per-family table + worst family + dispersion + coverage.

### DA-036 TLD product runner
Reuse controlled TLD methodology.

## Epic E — decision policy

### DA-040 Pareto frontier
No candidate hidden by opaque weighted score.

### DA-041 Audience presets
`agent_api`, `developer`, `business`, `consumer`.

### DA-042 Explanation receipt
Constraint proof + evidence links + uncertainty.

## Epic F — UI

### DA-050 Intent screen
### DA-051 Funnel screen
### DA-052 Arena battle/progress screen
### DA-053 Evidence matrix
### DA-054 Candidate detail
### DA-055 Registration/receipt screen
### DA-056 Evolution tree (stretch)

## Epic G — agent-native API

### DA-060 REST endpoints
### DA-061 MCP read-only tools
### DA-062 Gated registration MCP tool

## Epic H — demo/quality

### DA-070 Budget fixture
An expensive “great” domain is removed before evaluation.

### DA-071 Model disagreement fixture
High-mean unstable candidate loses to robust candidate.

### DA-072 TLD fixture
Same SLD, controlled TLD contrast.

### DA-073 Stale inventory fixture
Winner becomes unavailable before purchase; next Pareto candidate promoted.

### DA-074 Failure injection
Model outage, parse failure, name.com 429/5xx.

### DA-075 Submission regression
One script exercises complete sandbox demo.
