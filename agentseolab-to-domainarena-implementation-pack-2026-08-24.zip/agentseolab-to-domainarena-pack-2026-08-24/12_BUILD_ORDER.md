# Build order from current repo

## P0 — freeze lineage first

- ensure clean working tree
- record HEAD
- create/push baseline tag
- create `docs/HACKATHON_LINEAGE.md`
- update README subtitle to mention DomainArena as the product layer, without deleting the AgentSEOLab identity/history

## P1 — name.com vertical slice

Build the smallest end-to-end sponsor integration before any fancy evaluation:

```text
intent keyword
→ name.com Search
→ budget filter
→ CheckAvailability
→ user approval
→ sandbox CreateDomain
→ DNS TXT receipt
→ fetch/verify receipt
```

Tests must cover 401/429/5xx, stale availability, price drift, premium, duplicate retry/idempotency and empty feasible set.

## P2 — canonical intent + constraints

Implement:
- `DomainIntent`
- `ConstraintSet`
- canonical hash
- audience presets
- first-year and renewal hard filters

## P3 — heterogeneous candidate generation

Port only the good generators/features from `domainnamechecker`.
Add name.com Search as a generator/inventory source.

Goal: 100–200 raw candidates → 30 feasible/screened candidates cheaply.

## P4 — Semantic Inversion MVP

Run 3–5 evaluator families initially.
Measure task/category inference from hostname alone.
Persist raw output + parsed result + provider/model/version.

This is the feature that must work even if everything else gets cut.

## P5 — pairwise / executable Arena

- AB/BA pairwise runner
- Bradley–Terry strengths
- uncertainty/rank spread
- at least one controlled executable selection task for top candidates

## P6 — stability

Expose per-family matrix, worst-family outcome and serving coverage. Reuse AgentSEOLab's model registry and drift lessons.

## P7 — TLD integration

Reuse the existing TLD experiment machinery but attach it to real candidate SLDs only where multiple TLDs are feasible. Never hardcode the result.

## P8 — policy + Pareto recommendation

- build Pareto set
- audience preset chooses among Pareto candidates
- cost remains hard constraint
- explain why winner beat alternatives

## P9 — polished web UI

Implement the six screens from `11_UI_UX.md`.

## P10 — MCP / agent workflow

Expose `recommend_domain`, `compare_domains`, `refresh_domain_offer`, gated `register_domain`.

## P11 — EvoName stretch

Only after the full loop works. Three generations max for demo.

## P12 — submission hardening

- deterministic fixtures
- one command to run local stack
- README setup
- architecture diagram
- 2–4 minute demo
- explicit sponsor mapping
- limitations
