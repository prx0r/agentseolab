# Hackathon lineage and compliance

## Principle

Do not optimize for the appearance of having started from zero. Optimize for **transparent progress**.

The sponsor challenge explicitly allows extending an existing project. The safest evidence is:
- preserved repository history
- pre-DomainArena tag
- documented pre-existing capabilities
- clear list of hackathon additions
- source map for selectively adapted code from related repositories

## Before/after ledger template

### Pre-DomainArena / baseline
AgentSEOLab already contained:
- controlled agent-selection research
- model-family panel
- evidence ledger
- QLEX query-language work
- TLD experiment design/runner
- naming-science experiment program
- domain-related extraction/research

### Hackathon work
Must visibly include:
- DomainArena product workflow/UI
- name.com Core API integration
- hard pricing/renewal constraints
- live inventory-bound candidate population
- semantic inversion product runner
- recommendation/Pareto policy
- registration approval state machine
- name.com availability recheck
- name.com registration
- DNS receipt
- polished end-to-end demo

## Related repo source map

When code/logic is adapted:

```text
source repo: prx0r/domainnamechecker
source path: ...
source commit: ...
adapted path: ...
change: ...
```

and likewise for `finalbuildsdomain`.

Keep this in `docs/SOURCE_MAP.md`.

## Avoid

- rewriting git history
- copying a mature repo wholesale into a “new” repo with one import commit
- claiming pre-existing experiments were run during the hackathon
- presenting planned TLD/naming results as measured results
- hiding model failures or invalidated experiments
