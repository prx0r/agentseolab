# Research/source map

Use this file as the starting bibliography and evidence map. Verify URLs/details again at submission time because product docs can change.

## name.com / hackathon

- Devpost name.com challenge: https://api-cloud-ai-hackathon-2026.devpost.com/
  - current sponsor wording allows new or extended projects
  - rewards central API use, depth, originality, technical execution, viability, demo

- name.com Search API: https://docs.name.com/api/v1/reference/domains/search
  - live suggestions / purchasability / premium / purchase + renewal prices / purchase type

- Check Availability: https://docs.name.com/api/v1/reference/domains/check-availability
  - batch availability recheck; use immediately before purchase

- Get Pricing: https://docs.name.com/api/v1/reference/domains/get-pricing-for-domain

- DNS Create Record: https://docs.name.com/api/v1/reference/dns/create-record

- name.dev developer hub: https://www.name.dev/

- name.dev launch article: https://www.name.dev/updates/introducing-name-dev-the-developer-hub-for-the-name-com-api
  - explicit goal: help developers build domain experiences that convert

- Railway case study: https://www.name.dev/case-studies/railway-in-product-domains
  - demonstrates embedded domain purchase is already solved/proven; recommendation UX is the more interesting upstream layer

- name.com AI-native platform article: https://www.name.com/blog/the-first-ai-native-domain-platform

## Arena methodology inspiration

- Arena ranking methodology: https://arena.ai/blog/ranking-method
- Arena-Rank: https://arena.ai/blog/arena-rank
- Agent Arena causal evaluation: https://arena.ai/blog/agent-arena-methodology
- Agent Mode explanation: https://help.arena.ai/articles/5432423882-how-to-use-agent-mode

Key lesson: agent evaluation is moving beyond human pairwise preference toward real-task outcomes, causal signals, cost and tool behavior.

## Agentic search / discovery research

- Discovering Agents for Discovery: The Case for DNS (2026): https://arxiv.org/abs/2606.02314
  - motivates DNS as an agent discovery substrate; useful future extension

- How Much Can We Trust LLM Search Agents? (2026): https://arxiv.org/abs/2606.16821
  - model-family differences and vulnerability of recommendation behavior; reinforces need for family-level/stability evaluation

- Generative Engine Optimization: How to Dominate AI Search (2025): https://arxiv.org/abs/2509.08919
  - AI search engines differ in sourcing, freshness and phrasing sensitivity; supports separating exposure/retrieval from hostname selection

- Human Trust in AI Search (2025): https://arxiv.org/abs/2504.06435
  - human trust in generative search depends on interface/source cues; reinforces not reducing human behavior to aesthetic preference

## Current AgentSEOLab files

- `README.md`
- `THESIS.md`
- `RESULTS.md`
- `experiments-rules.md`
- `src/models.rs`
- `experiments/NAMING-SCIENCE/README.md`
- `experiments/TLD/README.md`
- `experiments/QLEX/REPORT.md`
- `experiments/VERIF/README.md`

## Related repos already inspected

### `prx0r/domainnamechecker`
- `HANDOVER-2026-08-21.md`
- `SPEC.md`
- `docs/NAMING_SCIENCE.md`
- `docs/HYDRA_SCHEMA.md`
- `docs/mcp.md`

### `prx0r/finalbuildsdomain`
- `README.md`
- `src/lifecycle/index.js`
- `src/oracle/index.js`
- `src/registrar/porkbun/client.js`
- `src/dns/cloudflare/client.js`
- `docs/ARCHITECTURE.md`
