# Test plan

## Unit

### Constraints
- purchase exactly at ceiling passes
- purchase above ceiling fails
- renewal above ceiling fails
- premium fails when disabled
- blocked TLD fails
- missing/unknown price fails closed

### Intent hash
Same canonical intent → same hash regardless of dict key order.
Changed constraint/audience → changed hash.

### Candidate lineage
Mutations retain parent IDs and generator provenance.

### Bradley–Terry
Synthetic known ordering recovered within tolerance; AB/BA input handling tested.

### Stability
Missing evaluator family changes coverage, not score as a fake zero.

## Integration — name.com client

Mock:
- 200 Search
- 429 retry/backoff
- 5xx failure
- malformed response
- purchasable=false
- premium=true
- aftermarket purchase type
- price changed before create
- idempotent registration retry
- DNS record create/list

Opt-in live sandbox:
- authenticated hello/search
- search/check availability
- sandbox create on a disposable fixture if account config allows
- DNS create/fetch-back

## Experiment integrity

- order counterbalancing
- no product description leaks into semantic-inversion hostname-only prompt
- prompt/manifest hash stable
- fresh session ID every trial
- model/provider provenance present
- unparseable output not counted as a vote
- rerunning analysis from raw ledger reproduces metrics

## End-to-end fixtures

### E2E-1 Budget
User asks under $20; every evaluated candidate must satisfy that snapshot constraint.

### E2E-2 Model disagreement
Candidate A high mean/high variance; B slightly lower mean/high floor. Agent/API preset recommends B and explains why.

### E2E-3 Human consumer
Consumer preset runs human-oriented metrics or fixture data and can choose differently from agent preset.

### E2E-4 Stale purchase
Recommended domain becomes unavailable during refresh; registration is blocked and next candidate offered.

### E2E-5 No feasible inventory
Return a useful structured result: broaden TLD/budget suggestions, but never silently violate constraints.

## Demo regression

A single script should verify:

```text
intent freeze
name.com search
constraint filter
semantic arena
pairwise/stability
recommendation
fresh availability
approval
sandbox registration
DNS receipt
final evidence receipt
```
