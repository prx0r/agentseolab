# Hackathon submission strategy

## Sponsor fit

The name.com challenge rewards:
- API integration depth
- creativity/originality
- technical execution
- real-world viability
- presentation/demo

DomainArena mapping:

### Integration depth
Search + CheckAvailability + pricing + CreateDomain + domain update + DNS.

### Originality
Not an incremental search UI: experimental evaluation of which purchasable name works for a specific human/agent audience.

### Technical execution
- hard economic constraints
- stale inventory handling
- idempotent purchase
- multi-model evidence
- AB/BA controls
- uncertainty
- append-only raw trials

### Viability
- direct founder/developer product
- embedded recommendation API for AI builders/platforms
- agent-native MCP demand funnel into name.com

### Demo
A real/sandbox end-to-end flow where name.com inventory changes the candidate set and the final winner is registered/configured.

## Overall-hackathon framing

Problem:
> AI can generate software instantly, but naming remains subjective and the available namespace is constrained, priced and constantly changing.

Insight:
> The “best name” depends on who must understand it. For agent-facing software, machine interpretation and task success can be more important than founder aesthetics.

Product:
> DomainArena experimentally selects the best purchasable domain under real constraints.

Startup story:
> Recommendation infrastructure for the wave of AI-generated apps/tools, with transaction revenue/demand flowing through a registrar partner.

## Suggested title

**DomainArena — Evidence-Based Naming for the Agentic Web**

## Suggested one-liner

**Find the best domain under your budget by testing which names humans and AI agents actually understand and select — then register the winner through name.com.**

## Submission transparency paragraph

> DomainArena evolved from AgentSEOLab, an empirical research project begun immediately before the hackathon to study how autonomous agents discover, select and invoke online capabilities. We preserved the repository history and tagged the pre-DomainArena baseline. During the hackathon we productized that research into the DomainArena application and added the name.com inventory, pricing, registration and DNS workflow. Supporting generation/verification ideas adapted from our related domain experiments are documented in the source map.

This is stronger than pretending the repo had no history.
