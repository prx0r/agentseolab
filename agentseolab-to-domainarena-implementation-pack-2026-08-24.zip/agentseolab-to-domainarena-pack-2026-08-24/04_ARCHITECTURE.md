# DomainArena architecture

## System boundaries

```text
┌─────────────────────────────────────────────────────┐
│                     CLIENTS                         │
│ Web UI        REST client        MCP/coding agent  │
└───────────────┬───────────────────┬─────────────────┘
                │                   │
                ▼                   ▼
┌─────────────────────────────────────────────────────┐
│               DOMAINARENA ORCHESTRATOR              │
│ intent → constraints → generation → arena → policy  │
└───────┬──────────────┬────────────┬─────────────┬────┘
        │              │            │             │
        ▼              ▼            ▼             ▼
  Name generators  name.com     Evaluator      Evidence
  heterogeneous    provider     model panel     ledger
        │              │            │             │
        └───────┬──────┴──────┬─────┴─────────────┘
                ▼             ▼
        Feasible inventory   Raw trials
                │             │
                └──────┬──────┘
                       ▼
                 Pareto/policy
                       │
                       ▼
                recommendation
                       │
             explicit approval gate
                       │
                       ▼
             name.com register + DNS
```

## Runtime recommendation

### Backend
- Python 3.12+
- FastAPI
- Pydantic v2
- `httpx` for name.com
- existing AgentSEOLab model-provider adapters where valid
- SQLite for local/dev, Postgres/D1 optional for hosted deployment

### Frontend
Use the fastest stack the coding agent is comfortable shipping reliably. A Vite/React or Astro frontend is sufficient. The UI is visualization-heavy but not application-framework-heavy.

### Jobs
Deep Arena evaluations can run as bounded jobs with progress events. Do not create an asynchronous promise to the hackathon user without a working execution path. For the demo, use a bounded candidate count that completes predictably.

## Domain objects

- `DomainIntent`
- `ConstraintSet`
- `Candidate`
- `InventorySnapshot`
- `ExperimentManifest`
- `Trial`
- `MetricBundle`
- `ParetoCandidate`
- `RecommendationDecision`
- `Approval`
- `RegistrationReceipt`

## Hard rule

**The recommendation engine cannot evaluate candidates that have not been bound to an inventory snapshot.**

This prevents the classic AI-domain-generator failure mode: beautifully ranking domains that cannot be bought.

## Caching

Safe to cache:
- deterministic name features
- prior evaluator trial results keyed by frozen manifest/model version
- name.com search snapshots for short periods for browsing

Must recheck before purchase:
- availability
- purchase price
- renewal price where relevant
- purchase type

## Failure isolation

A single evaluator/model outage must not turn into a negative score. Mark coverage missing.

A name.com outage must not fabricate availability. Return `INVENTORY_UNKNOWN` and block purchase.

A failed registration retry must use the same idempotency key.
