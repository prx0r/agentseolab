# Product specification

## One-line pitch

**DomainArena finds the best purchasable domain for a product by testing names across humans and AI agents instead of asking one model what “sounds good.”**

## Primary user stories

### Builder
> Find the best domain for an evidence-verification API under $20 first year and $30 renewal. It must make sense to developers and AI agents.

### Coding agent
> Recommend a domain for this new MCP service. Budget $15. No premium names. Prefer .com/.dev/.io. Return evidence and do not purchase without approval.

### Platform partner
> Given a project description and account policy, return a ranked set of purchasable domains with price, renewal, model stability and semantic evidence.

## Inputs

- product description
- primary job to be done
- audiences: consumer / business / developer / AI agent
- hard purchase budget
- hard renewal ceiling
- premium allowed?
- allowed / blocked TLDs
- length / hyphen / digit constraints
- current-category precision preference
- brand elasticity preference
- optional human vs agent weighting

## Outputs

Never return only `94/100`.

Return:
- recommended domain
- live/sandbox availability evidence
- purchase price
- renewal price
- premium flag / purchase type
- semantic transmission by evaluator family
- pairwise outcome with uncertainty
- model stability / worst-family outcome
- agent task-recognition result
- TLD evidence if actually measured
- human memory/trust evidence if actually measured
- brand elasticity estimate with method label
- constraint satisfaction proof
- experiment/run IDs
- timestamp

## Product modes

### 1. Quick Arena
Cheap deterministic screen + small evaluator panel. Target interactive latency.

### 2. Deep Arena
More candidates, more model families, AB/BA trials, stability analysis and optional EvoName generations.

### 3. Agent Mode
Structured API/MCP response, explicit budget policy, non-destructive recommendation by default.

### 4. Research Mode
Full experiment manifests, raw runs, confidence intervals, preregistration and result ledger.

## Audience-conditioned policy presets

### Agent/API preset
- semantic transmission: very high
- task inference: very high
- selection/invocation: very high
- model stability: high
- query-language compatibility: medium
- human aesthetics: low
- cost: hard constraint + secondary tie-break

### Developer preset
- semantic transmission: high
- agent selection: high
- developer comprehension: high
- memory/pronunciation: medium
- stability: high
- elasticity: medium

### Consumer preset
- human recall: high
- pronunciation/spelling: high
- trust: high
- semantic fit: medium-high
- elasticity: high
- agent selection: medium

## Non-goals for hackathon

- domain investment speculation
- universal Google/AI ranking claims
- full registrar portfolio manager
- generic site deployment platform
- trademark legal opinion
- 20-generation genetic optimization
- autonomous purchasing without a clear policy/approval boundary
