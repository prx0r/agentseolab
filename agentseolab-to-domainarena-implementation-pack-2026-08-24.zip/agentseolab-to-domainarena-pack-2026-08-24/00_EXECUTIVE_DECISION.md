# Executive decision

## What to build

Build **DomainArena inside `prx0r/agentseolab`** and make AgentSEOLab the research engine beneath the product.

Do not build a generic “agent launches a site and buys a domain” product. name.com already markets an AI-native registrar API, MCP support, autonomous registration/DNS flows, and partner integrations with platforms such as Railway, Vercel, Netlify, Lovable and Replit. Their partner stories already demonstrate that embedded domain search → purchase → management is commercially proven.

The unsolved layer is upstream:

> **Given an intent, audience and budget, which available domain should an agent or builder choose — and can we produce evidence rather than a vibe?**

That is where AgentSEOLab is unusually well positioned.

## Product wedge

**DomainArena = an Arena-style evaluation system for domains.**

But copy Arena's methodological lesson, not merely the head-to-head UI. Arena's recent agent work moved beyond human preference into confirmed task success, tool behavior, cost and causal outcomes. DomainArena should likewise treat pairwise preference as only one signal.

### Primary workflow

```text
intent + audience + constraints
        ↓
heterogeneous name generation
        ↓
name.com live search / availability / prices
        ↓
hard feasibility filter
        ↓
semantic inversion
        ↓
agent selection + task-success trials
        ↓
cross-model stability
        ↓
TLD causal tests where possible
        ↓
Pareto frontier / audience policy
        ↓
recommendation + evidence receipt
        ↓
explicit approval
        ↓
name.com recheck → register → DNS
```

## Why this is valuable to name.com

1. **Conversion layer:** improve search-to-registration conversion by reducing choice overload and bad recommendations.
2. **Partner primitive:** an embedded `recommend_domain(intent, constraints)` layer for AI builders and deployment platforms.
3. **Demand generation:** agents can call DomainArena because its naming quality is better than a one-shot LLM; every successful recommendation naturally terminates in name.com inventory/registration.
4. **TLD intelligence:** learn `TLD × task × audience × model` interactions rather than applying global folklore like “.com is always best.”
5. **Agentic-web research:** name.com explicitly positions domains as infrastructure for agentic identity and discovery; DomainArena can generate empirical data about how agents interpret domains.
6. **Economic optimization:** budget and renewal limits are native to the recommendation, so live name.com pricing materially changes the answer.
7. **Moat:** over time, registration and field outcomes create a dataset of revealed domain preference and downstream performance.

## What NOT to claim

Do not claim that a good domain automatically ranks higher in Google or AI search. The product must keep these stages separate:

- **retrieval/exposure:** was the site/tool surfaced?
- **selection:** once surfaced, was it chosen?
- **invocation:** was it called correctly?
- **success:** did the task complete?
- **reuse:** did the agent/user return?

The hostname may influence some of these stages, but DomainArena exists to **measure** the effects, not assume them.
