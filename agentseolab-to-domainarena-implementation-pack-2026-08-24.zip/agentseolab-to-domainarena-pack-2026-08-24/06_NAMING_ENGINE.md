# Naming engine

## Principle

Do not ask one LLM to generate and grade its own names.

Use a population of generators with different inductive biases, then evaluate outputs independently.

## Stage 0 — freeze intent

Before generation, compile the user brief into a canonical `DomainIntent` and hash it.

Required fields:
- primary job
- object(s)
- desired associations
- prohibited meanings
- audiences
- current category
- adjacent/future categories
- geography/language if relevant
- constraints

Every candidate and trial references `intent_hash`.

## Stage 1 — heterogeneous generators

Minimum generator families:

1. **descriptive** — literal job/category
2. **action-object** — functional verb + object
3. **suggestive compound** — conveys benefit without literal category lock-in
4. **metaphor/object** — physical analogies
5. **animal/archetype** — compressed behavioral meaning
6. **phonosemantic invented** — novel forms with targeted sound/shape
7. **morphological blend** — recombine useful morphemes
8. **contrarian** — deliberately explores outside population convergence
9. **name.com discovery** — use Search suggestions as a population source

Store generator provenance; never merge away lineage.

## Stage 2 — live inventory intersection

For each promising root/keyword, query name.com and construct `Candidate` objects only from current results.

```text
candidate = name structure + actual TLD + price + renewal + premium + purchase type
```

A `.com` and `.dev` variant are separate candidates because TLD and economics differ.

## Stage 3 — deterministic screen

Cheap filters only:
- valid IDNA/domain syntax
- length
- hyphens/digits policy
- obvious spelling ambiguity
- duplicate/near-duplicate clustering
- prohibited meanings
- simple phonotactic/pronunciation features
- exact query-keyword match (feature, not automatic bonus)

Do not pretend these produce the final answer.

## Stage 4 — semantic inversion

Signature metric:

> Given only the hostname, what task/category does an independent evaluator infer?

Avoid asking “is this a good name?”

Use a combination of:
- blinded classification among task distractors
- structured attribute inference
- short free-text interpretation mapped by a separate parser/judge

Primary output:

```text
SemanticTransmission = P(intended concept inferred | hostname only)
```

Report by model family.

## Stage 5 — pairwise task-conditioned selection

Give the actual task and two candidate hostnames, randomize AB/BA, and ask which endpoint/site the evaluator would choose.

Do not expose generator identity.

Fit Bradley–Terry strengths where there are ≥3 candidates and report uncertainty/rank spread.

## Stage 6 — executable selection

For top candidates, build a controlled synthetic search/tool environment where the hostname is the manipulated feature and the agent must actually choose and invoke a capability.

Primary endpoint:

```text
UsefulSelection = selected_candidate AND task_verified
```

This is more valuable than stated preference.

## Stage 7 — stability

Compute separately by:
- model family
- provider
- serving window
- task class

Recommended robust objective components:

```text
mean outcome
worst-family outcome
cross-family variance
coverage
```

Do not hide a catastrophic family failure inside a good average.

## Stage 8 — brand elasticity

This is a different objective from semantic transmission.

Ask whether the name can plausibly extend to adjacent categories without becoming misleading.

Report a two-axis view:

```text
semantic precision  ↔  category elasticity
```

Avoid collapsing to one aesthetic number.

## Stage 9 — human tests when audience requires them

Human tests should prefer behavioral tasks over ratings:
- recall
- recognition
- spelling reconstruction
- speech transcription
- category inference
- controlled trust choice

A consumer preset should weight these heavily; an API-agent preset may not run them at all.

## EvoName — stretch feature

Use top candidates as parents and mutate:
- semantic neighbor replacement
- compound recombination
- prefix/suffix deletion
- metaphor substitution
- phonetic simplification
- action/object swap
- TLD mutation
- contrarian mutation

Every mutation must return through name.com feasibility checks before evaluation.

Three generations is enough for the hackathon. Preserve the lineage tree for visualization.
