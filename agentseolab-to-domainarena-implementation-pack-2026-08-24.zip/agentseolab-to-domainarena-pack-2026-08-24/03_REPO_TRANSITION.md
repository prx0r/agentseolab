# Evolving `agentseolab` in place

## Why this repo is the right canonical entry

The repository already has a coherent scientific lineage around agent discovery, selection, invocation, trust, TLDs, query lexicons and naming science. DomainArena is not an unrelated product graft; it is a **direct productization of the lab's domain/selection work**.

The hackathon sponsor wording explicitly permits extending an existing project. Preserve and disclose the lineage.

## Baseline

As inspected on 2026-08-24, recent HEAD was:

`0f1ed4e3d53dfe7a5af9cfb6f435762db90ca974`  
`QLEX standalone report: convergence + functional-core + vendor-vocab findings`

Before DomainArena-specific implementation, the agent should:

```bash
git status
git rev-parse HEAD
git tag -a pre-domainarena-hackathon-2026-08-24 -m "AgentSEOLab baseline before DomainArena productization"
git push origin pre-domainarena-hackathon-2026-08-24
```

If HEAD has advanced, tag the actual current clean HEAD and record it in `docs/HACKATHON_LINEAGE.md`.

## Do NOT rewrite history

Do not squash the historical AgentSEOLab work into a synthetic “initial commit.” Do not copy the other repositories wholesale and pretend the code was written during the hackathon.

Instead, keep an explicit source map and port only what is needed.

## Recommended tree

Keep the existing lab intact and add a product surface:

```text
agentseolab/
├── AGENTS.md
├── RESULTS.md
├── THESIS.md
├── experiments-rules.md
├── experiments/                 # existing scientific programs
├── runner/                      # existing execution runners
├── results/                     # evidence ledger
├── analysis/
├── src/                         # existing Rust lab types/store
│
├── domainarena/                 # NEW product backend
│   ├── __init__.py
│   ├── config.py
│   ├── models.py
│   ├── intent.py
│   ├── constraints.py
│   ├── candidates.py
│   ├── optimizer.py
│   ├── receipts.py
│   ├── providers/
│   │   └── namecom.py
│   ├── generators/
│   ├── arena/
│   │   ├── semantic_inversion.py
│   │   ├── pairwise.py
│   │   ├── stability.py
│   │   └── tld.py
│   └── api/
│       ├── http.py
│       └── mcp.py
│
├── web/                         # NEW polished product UI
├── tests/domainarena/
└── docs/
    ├── HACKATHON_LINEAGE.md
    ├── DOMAINARENA_ARCHITECTURE.md
    └── DOMAINARENA_DEMO.md
```

## Why Python for the product backend

AgentSEOLab's live experimental runners and analysis are already Python-heavy. A Python/FastAPI product layer can directly call the evaluator/model adapters and analysis functions with minimal bridge code.

Keep the Rust crate intact for existing scientific types/store and future hardening. Do not block the hackathon on rewriting the product into Rust or building a Rust↔Python FFI layer.

## Source crosswalk

### From AgentSEOLab — reuse directly
- `src/models.rs`: intent, trial, pairwise, outcome concepts
- `experiments-rules.md`: controls/statistics/evidence ladder
- `experiments/NAMING-SCIENCE/`: naming experiments
- `experiments/TLD/`: TLD causal experiment
- `experiments/QLEX/`: query lexicon findings
- `experiments/VERIF/`: trust/provenance signal research
- `runner/`: provider/model adapters and experiment execution machinery
- `results/ledger/`: evidence discipline

### From domainnamechecker — port selectively with attribution/source map
- authoritative availability/RDAP concepts
- proof receipts
- candidate generation families
- semantic/name feature extraction
- MCP patterns
- domain normalization/validation
- naming-science thesis

### From finalbuildsdomain — port selectively with attribution/source map
- guarded purchase lifecycle
- idempotency and budget concepts
- post-registration validation
- domain decision/policy concept

Replace Porkbun-specific action paths with name.com.

## Suggested commit sequence

1. `docs(domainarena): declare product thesis and hackathon lineage`
2. `feat(namecom): add sandbox client and contract tests`
3. `feat(intent): freeze canonical domain intent before generation`
4. `feat(candidates): add heterogeneous naming population and live inventory intersection`
5. `feat(arena): implement semantic inversion evaluation`
6. `feat(arena): add AB/BA pairwise tournament and uncertainty`
7. `feat(stability): expose per-family outcomes and robustness`
8. `feat(tld): productize controlled TLD evaluation`
9. `feat(policy): hard purchase/renewal/TLD constraints and Pareto selection`
10. `feat(register): availability recheck, explicit approval, idempotent registration`
11. `feat(dns): write and verify DomainArena experiment receipt`
12. `feat(web): ship interactive Arena interface`
13. `feat(mcp): add agent-native recommend/compare/register tools`
14. `test(domainarena): fixtures, failure injection and full demo regression`
15. `docs(submission): demo script, architecture and sponsor mapping`

This commit history tells the exact story the judges should see.
