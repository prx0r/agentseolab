# Experimental protocol

DomainArena must inherit AgentSEOLab's strongest property: it invalidates its own claims when the machinery is wrong.

## Mandatory controls

- one causal independent variable per controlled experiment
- frozen intent before candidate generation
- fresh session per trial
- AB/BA balanced order
- seeded shuffle
- generator identity hidden from evaluator
- actual provider/model/version recorded
- raw output retained
- `UNPARSEABLE` is not a loss
- experiment manifest hashed before run
- derived metrics rebuildable from raw events
- failed/invalidated experiments retained

## Important change to old AgentSEOLab rules

The original rules standardize a fixed model batch for comparability. Keep a canonical panel, but DomainArena must support **coverage degradation** rather than blocking a recommendation when one free provider is unavailable.

Product output must state:

```text
Evaluator coverage: 6 / 8 canonical families
Missing: M4, M7
```

Research claims requiring replication still obey the stricter evidence ladder.

## Evaluation ladder

### L0 — deterministic quality gate
No causal claim.

### L1 — semantic inversion
Measures interpretation from hostname alone.

### L2 — pairwise task selection
Measures preference/selection under exposure.

### L3 — executable synthetic environment
Measures selection → invocation → verified task success.

### L4 — controlled TLD/name counterfactual
Identical content/metadata, hostname or TLD swapped.

### L5 — field telemetry
Real exposure/select/invoke/reuse outcomes.

Do not use L1 evidence to claim L5 effects.

## Statistics

### Two-candidate proportions
Wilson confidence interval.

### Multi-candidate tournaments
Bradley–Terry latent strengths with uncertainty.

Arena.ai publishes an open ranking methodology; for hackathon speed, use a transparent BT implementation or their permissively licensed package only if dependency/license review is clean. Do not make the product depend on an external ranking package if a small tested implementation is more reliable.

### Multiple exploratory variants
Benjamini–Hochberg correction where appropriate.

### Correlated repeated trials
Cluster/bootstrap by intent × model family.

## Stability metrics

Store raw per-family outcomes. Derived display values can include:

```text
mean
min / worst family
std deviation
interquartile range
coverage
```

If an overall robustness score is needed internally, document the formula and keep it out of the headline UI unless interpretable.

## Drift

A domain can be re-evaluated over time against the same frozen manifest. This creates:

```text
Domain Robustness Over Time
```

Use AgentSEOLab's sentinel/drift work as the template.

## Evidence statuses

Reuse:

`PROPOSED → PREREGISTERED → RUNNING → PROVISIONAL → CONFIRMED → REPLICATED`

plus:
- `FAILED_REPLICATION`
- `INVALIDATED`
- `STALE`

Product recommendations may use provisional evidence but must label it; scientific claims require the stronger ladder.
